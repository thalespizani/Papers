# Padrões HTML dos papers — cookbook

Isto traduz `identidade-visual.md` e `componentes.md` (que descrevem o
sistema de governança inteiro) para o subconjunto usado nos papers. Onde
este arquivo e aqueles divergirem em algum detalhe fino, os dois originais
mandam — este é só o atalho de copiar-e-colar. Para um exemplo inteiro e
funcionando, abra `assets/exemplo-paper-saude-mg.html`.

Todo trecho abaixo assume as variáveis Tailwind (`ses-green`, `ses-blue`
etc.) já configuradas no `<head>` — ver seção 1.

## 1. Boilerplate do `<head>`

Copie o `<head>` inteiro de `assets/exemplo-paper-saude-mg.html` (do
`<!DOCTYPE html>` até o fechamento de `<style>`). Ele já traz:

- `tailwind.config` com as cores `ses-*` da identidade
- Google Fonts Inter (300–900)
- Lucide via CDN
- `.wave-overlay` (onda institucional), `.bg-grid-white`, `.fade-in`
- `#global-tip` (balão de mouse-over) com toda a lógica de posicionamento
- `.bar` / `.bar-track` (barras de gráfico) e variantes de cor
- estilo de `<table>` (`.tnum`, `thead th`, `tbody td`, `tr.total`)
- scrollbar customizada, bloco `prefers-reduced-motion`, `@media print`

Não recrie isso do zero — copie e só adicione o que faltar (nova variante
de cor de barra, por exemplo).

## 2. Hero

```html
<div class="relative overflow-hidden rounded-[40px] shadow-md bg-gradient-to-br from-ses-green to-[#4f7a24] p-8 sm:p-12 wave-tide">
  <div class="wave-overlay"></div>
  <div class="absolute inset-0 bg-grid-white opacity-60 pointer-events-none"></div>
  <div class="absolute -right-16 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
  <div class="absolute -left-10 -bottom-16 w-48 h-48 bg-black/10 rounded-full blur-3xl pointer-events-none"></div>
  <div class="relative z-10 flex items-center gap-5 min-w-0">
    <div class="bg-white/20 backdrop-blur-md border border-white/25 text-white p-4 rounded-2xl shadow-inner shrink-0">
      <i data-lucide="heart-pulse" class="w-8 h-8"></i>
    </div>
    <div class="min-w-0">
      <p class="text-[10px] font-black text-white/70 uppercase tracking-[0.25em] mb-1">Secretaria de Estado de Saúde de Minas Gerais · SES-MG</p>
      <h1 class="text-4xl sm:text-5xl font-black text-white tracking-tight drop-shadow-sm">Título do Paper</h1>
    </div>
  </div>
</div>
```

Não adicione nada à direita do hero por padrão — já foi pedido para
tirar uma vez. Só ponha algo ali se o pedido pedir explicitamente.

## 3. Barra de navegação (pills)

Uma pill por tema, **centralizada** (não left-aligned — já foi corrigido
uma vez por ficar assimétrico):

```html
<div class="bg-white rounded-[28px] border border-slate-100 shadow-sm p-4 sm:p-5 no-print">
  <div class="flex flex-wrap items-center justify-center gap-2">
    <a href="#tema-1" class="px-4 py-2 rounded-full text-[11px] font-black uppercase tracking-wider transition-all border shadow-sm bg-ses-green text-white border-ses-green shadow-md">Tema 1</a>
    <a href="#tema-2" class="px-4 py-2 rounded-full text-[11px] font-black uppercase tracking-wider transition-all border shadow-sm bg-white text-slate-500 border-slate-200 hover:border-slate-300">Tema 2</a>
  </div>
</div>
```

O JS de scroll-spy (IntersectionObserver) que ativa a pill correspondente
já está no exemplo — copie o bloco `Pills de navegação` do `<script>`
final. Ele funciona por `id` de `<section>`, então basta cada seção nova
ter um `id` único e um link `href="#id"` correspondente.

## 4. Seção de tema

```html
<section id="tema-1" class="bg-white rounded-[40px] border border-slate-200 shadow-sm p-6 sm:p-10 space-y-8 scroll-mt-6">
  <div class="flex items-center gap-4">
    <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-ses-green to-[#4f7a24] flex items-center justify-center shadow-md relative overflow-hidden shrink-0">
      <div class="absolute -right-2 -top-3 w-9 h-9 bg-white/15 rounded-full pointer-events-none"></div>
      <i data-lucide="ícone-do-tema" class="w-7 h-7 text-white relative z-10"></i>
    </div>
    <div>
      <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tema 0N</p>
      <h2 class="text-3xl font-black text-ses-darkblue tracking-tight">Nome do Tema</h2>
    </div>
  </div>

  <!-- parágrafo de contexto — só se agregar informação real (ver seção 6) -->

  <!-- números grandes, tabelas, gráficos... -->
</section>
```

Ícone verde para o tile de todo tema — não use azul/laranja de eixo aqui
(esse par de cores é do sistema de governança em si, não faz sentido nos
papers). Escolha um ícone Lucide diferente por tema para dar identidade
visual a cada um (`siren`, `hospital`, `stethoscope`, `building-2`,
`scan-line`, `landmark`, `building`...).

## 5. Divisor de subseção

Antes de qualquer tabela/gráfico dentro de um tema, um divisor com ícone:

```html
<div class="flex items-center gap-3 pb-4">
  <div class="flex items-center gap-2 text-slate-400">
    <i data-lucide="wallet" class="w-4 h-4"></i>
    <span class="text-[10px] font-black uppercase tracking-widest">Nome da subseção</span>
  </div>
  <span class="flex-1 h-px bg-slate-200"></span>
</div>
```

## 6. Parágrafo de contexto

```html
<p class="text-sm font-medium leading-relaxed text-slate-600">Uma ou duas frases, sempre com números reais dentro do texto — nunca só qualificação vaga.</p>
```

Só entra quando adiciona informação que os números sozinhos não dão
(um marco, uma meta, uma nota metodológica). Ver seção 8 do `SKILL.md`
— o paper original foi pedido "sem muito texto", e frases de preenchimento
já foram cortadas mais de uma vez.

## 7. Números grandes (stat cards)

Card de destaque (gradiente verde, para o número mais importante do
grupo) e cards neutros ao lado, sempre na mesma altura:

```html
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
  <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-ses-green to-[#4f7a24] p-6 shadow-md flex flex-col">
    <div class="absolute -right-8 -top-10 w-40 h-40 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
    <p class="text-[10px] font-black text-white/70 uppercase tracking-[0.25em] mb-2">Rótulo</p>
    <p class="text-5xl font-black text-white tnum tracking-tight">253</p>
    <p class="text-xs font-bold text-white/80 mt-2">Legenda curta</p>
  </div>
  <div class="bg-slate-50 rounded-3xl p-6 border border-slate-100 flex flex-col">
    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Rótulo</p>
    <p class="text-4xl font-black text-slate-800 tnum tracking-tight">434</p>
    <p class="text-xs font-bold text-slate-500 mt-2">Legenda curta</p>
  </div>
</div>
```

`items-stretch` no grid + `flex flex-col` em cada card = todos com a
mesma altura mesmo que o conteúdo interno varie (já foi um bug real:
um card com barra de progresso ficava mais alto que os vizinhos).

**Número visivelmente arredondado** (ex.: um total de portfólio que
"parece" R$ 700.000.000,00 redondo demais para ser exato): prefixe com
`≈` e escreva por extenso — `≈ R$ 700 <span class="text-lg text-white/70">milhões</span>`.
Nunca faça isso com um valor oficial preciso (com centavos) — aí é para
mostrar exato.

## 8. Tabela

```html
<div class="overflow-x-auto">
  <table class="tnum">
    <thead>
      <tr><th>Ano</th><th>Coluna A</th><th>Coluna B</th></tr>
    </thead>
    <tbody>
      <tr><td>2024</td><td>10</td><td>20</td></tr>
      <tr class="total"><td>Total</td><td>10</td><td>20</td></tr>
    </tbody>
  </table>
</div>
```

Primeira coluna sempre à esquerda (identificador); as demais, numéricas,
à direita — isso já é o padrão do CSS (`thead th:first-child`,
`tbody td:first-child`). Linha de total sempre com `class="total"`.
Valor ausente/não aplicável, depois de perguntado ao Paulo (ver Passo 2
do `SKILL.md` — não decida sozinho): `—`, nunca `0` (0 significa que o
dado existe e é zero; `—` significa que não há dado).

## 9. Gráfico de barras horizontal (série temporal)

```html
<div class="bg-slate-50 rounded-3xl p-5 space-y-3">
  <div class="flex items-center gap-3">
    <span class="w-16 text-[11px] font-black text-slate-500 tnum shrink-0">2024</span>
    <div class="flex-1 bar-track"><div class="bar" style="width:88%"></div></div>
    <span class="w-20 text-right text-xs font-black text-slate-700 tnum shrink-0">970</span>
  </div>
  <!-- repita uma linha por ano/categoria -->
</div>
```

`width` da barra = percentual relativo ao maior valor da série (a maior
barra fica em 100%). Variantes de cor já no CSS: `.bar` (verde, padrão),
`.bar-orange` (para destacar um ano-base/exceção), `.bar-blue`.

## 10. Círculo dividido em N fatias (indicador de progresso "X de N")

Para "2 de 5 entregues" etc. — pizza com fatias separadas por linhas
finas, não um donut de stroke único (cores diferentes por fatia exigem
`<path>` por fatia). Fórmula para N fatias, ângulo por fatia = 360/N,
começando no topo (-90°) e indo em sentido horário:

```
cx = cy = 16, r = 12 (viewBox 0 0 32 32)
ponto_i = (16 + 12·cos(θ_i), 16 + 12·sin(θ_i)),  θ_i = -90 + i·(360/N) graus
```

Cada fatia `i` (de `ponto_i` a `ponto_i+1`):

```html
<path d="M16,16 L{x_i},{y_i} A12,12 0 0,1 {x_i+1},{y_i+1} Z"
      fill="#ffffff ou rgba(255,255,255,0.18)"
      stroke="rgba(255,255,255,0.4)" stroke-width="1.5" stroke-linejoin="round"/>
```

Branco opaco para as fatias "concluídas", `rgba(255,255,255,0.18)` para
as pendentes. Para N=5 as coordenadas já calculadas estão no exemplo
(seção "Hospitais Regionais"); para outro N, recalcule com a fórmula
acima (ou peça para calcular em Python antes de escrever o SVG — não
estime as coordenadas de cabeça, o desalinhamento fica visível).

## 11. Timeline / cronograma (etapas com linha conectando)

**Erro já cometido:** desenhar a linha conectora com uma `<div>`
absoluta posicionada por percentual (`left-[12.5%]`) enquanto os pontos
ficam alinhados à esquerda de cada coluna — a linha não passa no centro
dos pontos. A técnica correta: cada etapa carrega seu próprio pedaço de
linha logo após o ponto, então elas encostam ponta a ponta exatamente no
centro de cada bolinha, sem gap:

```html
<div class="bg-slate-50 rounded-3xl p-6 sm:p-8 shadow-inner overflow-x-auto">
  <div class="flex items-start flex-nowrap min-w-[560px]">
    <div class="flex-1 min-w-[130px]">
      <div class="flex items-center">
        <div class="w-3.5 h-3.5 rounded-full bg-ses-green border-2 border-white shadow shrink-0 z-10"></div>
        <div class="flex-1 h-0.5 bg-slate-200"></div>
      </div>
      <p class="text-xs font-black text-slate-800 mt-3 whitespace-nowrap">Etapa 1</p>
      <p class="text-[11px] font-bold text-slate-400 tnum">2026–2027</p>
    </div>
    <!-- etapas do meio: mesma estrutura -->
    <div class="shrink-0 min-w-[130px]">
      <!-- última etapa: SEM a div da linha (senão ela continua até o infinito) -->
      <div class="flex items-center">
        <div class="w-3.5 h-3.5 rounded-full bg-ses-green border-2 border-white shadow shrink-0 z-10"></div>
      </div>
      <p class="text-xs font-black text-slate-800 mt-3 whitespace-nowrap">Última etapa</p>
    </div>
  </div>
</div>
```

`overflow-x-auto` + `min-w` no container interno evita quebra feia em
tela estreita (rola horizontal em vez de espremer).

## 12. Chip de status (com detalhe no tooltip)

Quando o status tem uma frase inteira de contexto por trás (motivo,
fonte, nuance), não force tudo no chip — rótulo curto + `data-tip` com
o texto completo (usa o `#global-tip` já no boilerplate):

```html
<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-ses-green/10 border border-ses-green/20 text-[10px] font-black uppercase tracking-wider text-ses-green cursor-help"
      data-tip="Frase completa com o contexto que não cabe no chip.">
  <span class="w-2 h-2 rounded-full bg-ses-green"></span>Em operação
</span>
```

Semáforo de cor (mesma lógica do sistema de governança):
`ses-green` = concluído/operando · `blue-400`/`blue-50`/`blue-500` =
previsão informada ou em andamento · `slate-400`/`slate-50`/`slate-500`
= sem previsão ainda / neutro. Não invente uma data que a fonte não deu
— se não houver previsão específica, pergunte ao Paulo antes de pôr uma
(não escreva "a definir" como palpite silencioso sem avisar).

## 13. Aviso / nota metodológica (callout)

Para um alerta que precisa ser visto (ex.: "não some estes dois
totais"), cartão sólido/gradiente — **não amarelo/âmbar** (já foi trocado
uma vez por parecer alerta de erro quando é só uma nota):

```html
<div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-ses-blue to-ses-darkblue p-5 flex items-start gap-4 shadow-md">
  <div class="absolute -right-10 -top-12 w-40 h-40 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
  <div class="relative z-10 w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md border border-white/25 text-white flex items-center justify-center shrink-0">
    <i data-lucide="alert-triangle" class="w-5 h-5"></i>
  </div>
  <div class="relative z-10">
    <p class="text-[10px] font-black text-white/70 uppercase tracking-widest mb-1">Atenção</p>
    <p class="text-sm font-bold text-white leading-relaxed">Texto do aviso.</p>
  </div>
</div>
```

## 14. Rodapé

```html
<div class="relative overflow-hidden rounded-[40px] bg-gradient-to-br from-ses-green to-[#4f7a24] p-8 shadow-md wave-tide">
  <div class="wave-overlay"></div>
  <div class="absolute -left-10 -bottom-16 w-48 h-48 bg-black/10 rounded-full blur-3xl pointer-events-none"></div>
  <div class="relative z-10 flex items-center justify-between gap-4 flex-wrap">
    <div>
      <p class="text-[10px] font-black text-white/70 uppercase tracking-[0.25em] mb-1">Secretaria de Estado de Saúde de Minas Gerais</p>
      <p class="text-lg font-black text-white tracking-tight">Título curto</p>
    </div>
    <button onclick="window.print()" class="no-print text-[11px] font-black text-white uppercase tracking-widest flex items-center gap-2 bg-white/15 backdrop-blur-md hover:bg-white hover:text-ses-green px-5 py-3 rounded-2xl border border-white/25 shadow-sm transition-all hover:-translate-y-0.5">
      <i data-lucide="printer" class="w-4 h-4"></i> Imprimir
    </button>
  </div>
</div>
```

## 15. Checklist de sanidade antes de entregar

Depois de escrever ou editar o HTML, rode (via `bash_tool`):

```python
html = open('/mnt/user-data/outputs/ARQUIVO.html').read()
for tag in ['div','section','table','thead','tbody','tr','span','svg']:
    o, c = html.count(f'<{tag}'), html.count(f'</{tag}>')
    if o != c:
        print(f'DESBALANCEADO: {tag} — {o} abrem, {c} fecham')
```

Rode sempre depois de qualquer `str_replace` no arquivo — uma edição que
corta um `</div>` no meio quebra o layout silenciosamente, sem erro de
ferramenta (já aconteceu: uma substituição removeu a abertura da tabela
de UBS por engano).
