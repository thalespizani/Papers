# Identidade visual do sistema — o vocabulário

Levantamento do que existe hoje no `index.html` e em `assets/js/*`. Tudo
aqui é descritivo, não aspiracional: são as decisões já tomadas.

---

## 1. Paleta

### Cores institucionais (`tailwind.config`, `index.html`)

| Token | Hex | Uso |
|---|---|---|
| `ses-green` | `#8dc63f` | **Cor do sistema.** Heros, item ativo da sidebar, pills ativas, botões primários globais, toast de sucesso, foco de input |
| `ses-lightgreen` | `#b2d235` | Segundo tom do verde: gradientes, marcadores de lista aninhada |
| `ses-blue` | `#007fb6` | **Eixo SUS** (assistencial) — identidade de projeto/processo |
| `ses-darkblue` | `#005b8e` | Tom escuro do SUS: títulos, segundo box, hover de botão |
| `ses-lightblue` | `#5ab0d8` | Tom claro do SUS: onda, fundo de tile de ícone (`/20`) |
| `ses-orange` | `#f58220` | **Eixo SES** (gestão interna) |
| `ses-darkorange` | `#d96c14` | Tom escuro do SES |
| `ses-yellow` | `#fdb913` | Onda do wave-bg-ses |

Verdes de gradiente usados como valor cru (não são token):
`#4f7a24` (hero das telas) e `#69a52c` (hero da home e tiles dos cards da home).

### Neutros

- Fundo da aplicação: `#f4f7f9` (`body` e `#main-content`)
- Superfície: `bg-white`
- Bordas: `border-slate-100` (interna, suave) e `border-slate-200` (card, divisor)
- Fundo de campo/caixa interna: `bg-slate-50`
- Texto: `slate-800` (título) · `slate-700` (corpo forte) · `slate-600` (corpo)
  · `slate-500` (secundário) · `slate-400` (rótulo, eyebrow) · `slate-300` (vazio)
- Tooltip: `#1e293b` (slate-800 sólido)

### Semáforo de situação (`CAL_STATUS_DOT`, `10-calendario.js`)

```js
concluido            → bg-ses-green
atraso               → bg-red-500
aguardando_validacao → bg-amber-400
em_andamento         → bg-blue-400
nao_iniciado         → bg-slate-300
```

Outros semânticos: `red-500` destrutivo · `amber-*` modo teste e pendências ·
`green-700` texto de avanço · `red-600` texto de atenção.

### A regra de significado (a mais importante)

> **Verde = o sistema.** Azul/laranja = **a que eixo a entidade pertence**.
> Semáforo = **em que situação a entrega está**.

Nunca misture os três papéis no mesmo componente. Se numa área a cor já
significa situação (o painel de entregas do Cronograma), o eixo sai dali e vai
para o cabeçalho do card.

**A comparação de eixo é sempre `eixoEhSes(eixo)`** — há registros gravados em
maiúsculas no banco; `eixo === 'ses'` já causou processo laranja numa tela e
azul em quatro outras.

---

## 2. Tipografia

Fonte única: **Inter** (300–900, via Google Fonts).

| Papel | Classes |
|---|---|
| Nome de entidade (detalhe) | `text-5xl font-black text-white drop-shadow-lg tracking-tight` |
| Título de tela (hero) | `text-4xl font-black text-white tracking-tight drop-shadow-sm` |
| Título de tela (documento) | `text-4xl font-black text-slate-800 tracking-tight` |
| Título de seção | `text-3xl font-black text-ses-darkblue tracking-tight` |
| Título de card | `text-lg font-black text-slate-800 tracking-tight leading-tight` |
| Eyebrow / rótulo | `text-[10px] font-black uppercase tracking-widest text-slate-400` |
| Eyebrow sobre verde | `text-[10px] font-black text-white/70 uppercase tracking-[0.25em]` |
| Botão / pill | `text-[10px]` ou `text-[11px]` `font-black uppercase tracking-widest` |
| Corpo | `text-sm font-medium leading-relaxed text-slate-600` |
| Corpo denso | `text-xs font-medium text-slate-500 leading-relaxed` |

Regras:
- **`font-black` domina.** Títulos, rótulos e botões são todos 900. `font-bold`
  para labels de campo, `font-medium` para corpo. `font-normal` praticamente
  não aparece.
- **Rótulo é sempre CAIXA ALTA + `tracking-widest` + minúsculo (10–11px).**
  É a marca tipográfica do sistema — mais reconhecível que a cor.
- `tracking-tight` / `tracking-tighter` em títulos grandes; `tracking-[0.1em]`
  a `[0.25em]` em rótulos.
- `.tnum` (`font-variant-numeric: tabular-nums`) em qualquer coluna de números.

---

## 3. Geometria — a escala de raios

O raio é o elemento mais característico do sistema. Ele cresce com o bloco:

| Raio | Onde |
|---|---|
| `rounded-full` | Pills, dots, avatar, botão-ícone circular, toggle glass |
| `rounded-lg` / `rounded-xl` | Micro-controles: botão do toggle segmentado, tile de nav, tile de ícone pequeno |
| `rounded-2xl` (16px) | Inputs, botões, chips, caixas internas, tile de ícone do hero |
| `rounded-3xl` (24px) | Boxes de conteúdo (justificativa/escopo), card da barra lateral |
| `rounded-[28px]` | **Card de lista e barra de filtros** — o raio "de tela" |
| `rounded-[32px]` | Modais, form de nova atualização |
| `rounded-[40px]` | Painéis grandes, cabeçalho de subsecretaria, tela de login, wrapper da timeline |
| `rounded-[45px]` | Bloco "Outras pautas" (o maior do sistema) |

Cantos assimétricos: `rounded-t-3xl` no cabeçalho de entidade +
`rounded-b-[40px]` no corpo que o sobrepõe com `-mt-8`.

### Sombras

- Repouso: `shadow-sm` → hover `shadow-md` / `shadow-lg`
- Modais e cabeçalho de sub: `shadow-2xl`
- Corpo do detalhe de entidade: `shadow-2xl` + `border-x border-b border-slate-200`
- Timeline: `shadow-inner` (afundada)
- Sombras coloridas só em botão primário: `shadow-lg shadow-ses-green/30`
- Sombra artesanal do "Outras pautas": `shadow-[0_20px_50px_-12px_rgba(0,0,0,0.1)]`
  → hover `shadow-[0_30px_60px_-15px_rgba(0,0,0,0.15)]`

### Espaçamento e largura

- View: `w-full max-w-[N] mx-auto px-4 sm:px-6 lg:px-8 py-8`
  - `1200px` home · `1400px` listagens e painéis · `1600px` repactuação · `1800px` detalhe
- Entre blocos da tela: `space-y-6` · Entre cards do feed: `gap-8`
- Card de lista: `p-5` · Barra de filtros: `p-4 sm:p-5` · Hero: `p-6 sm:p-8`
- Painéis grandes: `p-8` a `p-12`
- Grid do detalhe: `grid-cols-1 lg:grid-cols-12 gap-12` → `lg:col-span-9` + `lg:col-span-3`

---

## 4. Texturas e motivos — a assinatura

Estes são os elementos que fazem a tela "parecer do sistema". Todos vivem no
`<style>` do `index.html`.

### 4.1 A onda institucional

Uma silhueta SVG única, usada de três formas:

- **`.wave-bg-sus` / `.wave-bg-ses`** — fundo sólido do eixo + onda em tom
  claro (`fill-opacity 0.4`), ancorada no topo. É o cabeçalho de projeto/
  processo individual. Troca de classe = troca de eixo.
- **`.wave-overlay`** — a mesma onda em branco a 14%, ancorada embaixo,
  `position:absolute inset-0 pointer-events-none`. Não define fundo próprio,
  então **compõe sobre qualquer gradiente Tailwind**. É o que se usa em tela
  nova.
- **`.wave-tide`** — no pai; o hover desloca a onda de `bottom center` para
  `bottom right` em 0.7s. A "maré". Tem par `prefers-reduced-motion`.

Metáfora deliberada: o mesmo motivo em três escalas — hero da página,
cabeçalho de subsecretaria, cabeçalho de projeto — como uma maré que desce a
hierarquia de governança.

### 4.2 Orbes de luz

Sempre em pares opostos, dentro de um container `relative overflow-hidden`:

```html
<div class="absolute -right-16 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
<div class="absolute -left-10 -bottom-16 w-48 h-48 bg-black/10 rounded-full blur-3xl pointer-events-none"></div>
```

Sem `blur-3xl` (home) viram círculos nítidos — variação válida e mais gráfica.

### 4.3 Glass

Só sobre superfície colorida (hero, cabeçalho de eixo). Nunca sobre fundo claro.

- Tile do ícone: `bg-white/20 backdrop-blur-md border border-white/25 shadow-inner`
- Botão de ação: `bg-white/15 backdrop-blur-md border border-white/25` →
  `hover:bg-white hover:text-ses-green`
- Toggle segmentado: `bg-white/15 backdrop-blur-md border border-white/20 rounded-full p-1`,
  item ativo `bg-white text-ses-green shadow-md`

### 4.4 O balão de mouse-over (`#global-tip`)

Elemento único, `position:fixed`, filho direto do `body` — a única superfície
escura do sistema, e por isso muito reconhecível:

```
fundo #1e293b · texto branco 11px/1.45 peso 600 · padding 7px 11px
raio 8px · sombra 0 6px 20px rgba(0,0,0,.22) · fade de 0.12s
max-width min(340px, 100vw - 16px) · white-space: pre-line
overflow-wrap: anywhere · seta de 5px acompanhando o centro do gatilho
```

Acima do elemento por padrão, com flip para baixo (`.tip-below`) quando não
cabe. **Não replique esse visual em outro componente** — o escuro é a marca do
mouse-over e de mais nada.

### 4.5 Outros

- **`.header-watermark`** — ícone gigante a 30% de opacidade, ancorado à
  direita do cabeçalho de entidade.
- **`.bg-grid-white`** — pontilhado radial branco 10%, grade de 20px.
- **`.fade-in`** — entrada de 0.4s, `translateY(10px) → 0`. Vai no wrapper
  de todo conteúdo renderizado por JS.
- **Conectores da EAP** (`.eap-*`) — barramento em `::before`/`::after` de 2px
  `#cbd5e1`, recortado nas pontas por `.is-first`/`.is-last`. Árvore
  hierárquica desenhada em CSS puro, sem biblioteca.
- **Scrollbar customizada** — 8px, trilho `#f1f5f9`, polegar `#cbd5e1`.

---

## 5. Lógica de UI/UX — como o sistema se comporta

### Anatomia canônica de uma tela de trabalho

```
hero verde (gradiente + onda + orbes + glass)
      ↓
barra de filtros branca  rounded-[28px] border-slate-100 shadow-sm p-4 sm:p-5
      ↓
feed de cards  flex flex-col gap-8   (ou space-y-4 em painel denso)
```

### Filtros

- **Pill é o único controle de filtro.** Ativa: `bg-ses-green text-white
  border-ses-green shadow-md`. Inativa: `bg-white text-slate-500
  border-slate-200 hover:border-slate-300`. Sempre `rounded-full`,
  `text-[10px]/[11px] font-black uppercase tracking-wider`.
- **Muitas opções** (lista de pessoas, de projetos) → botão-pill **sempre
  branco**, mesmo com item ativo (o rótulo mostra a escolha), abrindo painel
  flutuante `position:fixed` com `left/top` calculados a partir do botão.
  Fixed, não absolute: é o que permite a barra rolar horizontalmente
  (`overflow-x-auto`) sem cortar o painel.
- **Cascata**: cada filtro só aparece depois da escolha anterior.
  Convenção de estado: `undefined` = ainda não escolhido; `null` = "TODOS"
  escolhido de propósito.
- Grupos separados por `<span class="w-px h-6 bg-slate-200 shrink-0"></span>`,
  cada um rotulado com o eyebrow de 10px.

### Divulgação progressiva

O sistema esconde bem. Padrões em uso:
- Card colapsado → expande painel (Cronograma, encaminhamentos)
- `<details>` com summary colorido ("Conheça o projeto")
- **Mouse-over `data-tip`** para o detalhe que não cabe (meta completo, desvio
  em dias, última atualização, valor anterior de um marco editado, aviso de
  fim de semana) — ver o item 12 de `componentes.md`
- Toggle segmentado para duas visões da mesma informação
  (timeline ↔ EAP, cronograma ↔ calendário)
- **Modo edição por toggle no ícone do título**, não em tela separada
  (Reunião de Entregas, "Gerenciar" de Processos)

### Feedback

- `showToast(msg)` sucesso (verde, canto inferior direito) e
  `showErrorToast(msg)` erro (vermelho, canto inferior esquerdo)
- **Escrita otimista**: grava no Supabase **e** nos globals `db_*`, re-renderiza
  local. Não invalida cache.
- Skeleton via `setViewLoading(containerId, true)` enquanto o cache está stale
- Estado vazio: card branco `rounded-[28px] py-20`, tile
  `w-16 h-16 rounded-2xl bg-slate-50 text-slate-300`, frase
  `text-sm font-bold text-slate-400`

### Modais

Overlay `bg-slate-900/40 backdrop-blur-sm z-50`; card `rounded-[32px]
shadow-2xl` com animação `scale-95 opacity-0 → scale-100 opacity-100`.
Cancelar é texto cinza sem fundo; confirmar é sólido colorido com ícone.
Destrutivo abre com círculo vermelho `w-16 h-16 bg-red-50 text-red-500` e
título em pergunta ("Tem certeza?", "Remover da Pauta?").

### Movimento

Durações: `transition-all duration-200/300` no geral · `duration-500` em troca
de tema por eixo · `0.7s` só na maré · `0.45s` na entrada de conteúdo.

Para uma tela nova, o suficiente é: hover de card
(`hover:-translate-y-0.5 hover:shadow-md`), tile de ícone clicável
(`hover:scale-105`), botão (`hover:-translate-y-0.5 active:translate-y-0`),
chevron que gira, `.fade-in` no wrapper do conteúdo renderizado, e
`opacity-0 group-hover:opacity-100` para revelar ação discreta.

**A camada de movimento completa tem skill própria: `/movimento`.** Ela cobre
o repertório inteiro (o que se move, com que gesto e por quê), as quatro
armadilhas que já custaram bug em produção aqui — animação que termina
deixando a tela vazia, dado que some com a animação em aba de fundo,
`prefers-reduced-motion` que quebra o layout, e tela que pisca a cada clique —
e as receitas de como verificar animação sem conseguir assisti-la. Carregue-a
quando for além do básico acima. A referência implementada é a
`view-monitoramento`.

Uma regra vale desde a tela nova, porque é cara de consertar depois:
**interação local não pode chamar a função de render da view** (ver item 15 de
`componentes.md`). E todo gesto novo entra junto com sua linha no bloco de
`prefers-reduced-motion` — no mesmo trabalho, nunca "depois".

### Telas estreitas

Desktop-first, degradando por etapas. Cabeçalho institucional encolhe por
media query em três faixas (1280 / 900 / 640) via ids `hdr-*`. A sidebar
recolhe sozinha abaixo de 900px (`aplicarSidebarResponsiva`, `02-dados.js`),
reaproveitando a classe `.sidebar-collapsed` do botão manual.
Elemento novo de cabeçalho: dar id `hdr-*` e decidir em qual faixa some.

### Ícones

**Lucide, sempre.** `lucide.createIcons()` obrigatoriamente após todo
`innerHTML`. `data-lucide` **nunca** passa por `sanitize()` (quebra o ícone).
Tamanhos: `w-3 h-3` (inline em rótulo) · `w-3.5 h-3.5` (botão pequeno) ·
`w-4 h-4` (botão) · `w-5 h-5` (nav, título de form) · `w-7 h-7` / `w-8 h-8`
(hero) · `w-10 h-10` (cabeçalho de sub) · `w-16 h-16 opacity-30` (decorativo).
