# Blocos prontos

Blocos extraídos do código em produção. Copie e troque só o que está marcado
com `⟨…⟩`. As classes são as que estão em uso — não "melhore" a lista de
classes: qualquer divergência aparece na tela ao lado da irmã.

---

## 1. Container da view (`index.html`)

```html
<!-- ========================================== -->
<!-- VIEW: ⟨NOME DA TELA⟩                       -->
<!-- ========================================== -->
<div id="view-⟨slug⟩" class="hidden-view w-full max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8 transition-opacity duration-300">
    <div id="⟨slug⟩-container"></div>
</div>
```

Larguras: `1200px` home · `1400px` listagem/painel · `1600px` repactuação ·
`1800px` detalhe de entidade.

---

## 2. Hero verde institucional

O bloco de abertura de toda tela nova. Gradiente + maré + orbes + glass.

```html
<div class="relative overflow-hidden rounded-[28px] shadow-md bg-gradient-to-br from-ses-green to-[#4f7a24] p-6 sm:p-8 wave-tide mb-6">
    <div class="wave-overlay"></div>
    <div class="absolute -right-16 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -left-10 -bottom-16 w-48 h-48 bg-black/10 rounded-full blur-3xl pointer-events-none"></div>
    <div class="relative z-10 flex items-center justify-between gap-4 flex-wrap">
        <div class="flex items-center gap-4 min-w-0">
            <div class="bg-white/20 backdrop-blur-md border border-white/25 text-white p-4 rounded-2xl shadow-inner shrink-0">
                <i data-lucide="⟨icone-lucide⟩" class="w-8 h-8"></i>
            </div>
            <h2 class="text-4xl font-black text-white tracking-tight drop-shadow-sm">⟨Título da Tela⟩</h2>
        </div>
        <!-- opcional: botão de ação principal ou toggle de visões -->
    </div>
</div>
```

**Variante com eyebrow** (quando a tela precisa de contexto — padrão do
Monitoramento; ícone em `p-3`/`w-7 h-7` e título `text-3xl`):

```html
<div class="min-w-0">
    <p class="text-[10px] font-black text-white/70 uppercase tracking-[0.25em] mb-0.5">Governança de Projetos e Processos · AEST</p>
    <h2 class="text-3xl font-black text-white tracking-tight drop-shadow-sm">⟨Título⟩</h2>
</div>
```

**Botão de ação sobre o hero:**

```html
<button onclick="⟨fn⟩()" class="relative z-10 text-[11px] font-black text-white uppercase tracking-widest flex items-center gap-2 bg-white/15 backdrop-blur-md hover:bg-white hover:text-ses-green px-5 py-3 rounded-2xl border border-white/25 shadow-sm transition-all hover:-translate-y-0.5 whitespace-nowrap">
    <i data-lucide="⟨icone⟩" class="w-4 h-4"></i> ⟨Rótulo⟩
</button>
```

**Toggle segmentado de visões (glass, canto do hero):**

```js
function ⟨tela⟩ToggleHTML() {
    const btn = (modo, icon, titulo) => {
        const ativo = ⟨estadoModo⟩ === modo;
        return `<button onclick="set⟨Tela⟩Modo('${modo}')" title="${titulo}"
            class="w-9 h-8 rounded-full flex items-center justify-center transition-all ${ativo ? 'bg-white text-ses-green shadow-md' : 'text-white/80 hover:bg-white/10'}">
            <i data-lucide="${icon}" class="w-4 h-4"></i>
        </button>`;
    };
    return `<div class="flex items-center gap-1 bg-white/15 backdrop-blur-md border border-white/20 rounded-full p-1 shrink-0">
        ${btn('⟨a⟩', '⟨icone-a⟩', '⟨Título A⟩')}
        ${btn('⟨b⟩', '⟨icone-b⟩', '⟨Título B⟩')}
    </div>`;
}
```

---

## 3. Barra de filtros

**Uma linha** (Despacho, Portfólio):

```html
<div class="bg-white rounded-[28px] border border-slate-100 shadow-sm p-4 sm:p-5 mb-6">
    <div class="flex flex-wrap items-center gap-3">
        <div id="⟨slug⟩-modo-pills" class="flex items-center gap-2 shrink-0"></div>
        <span class="w-px h-6 bg-slate-200 shrink-0"></span>
        <div id="⟨slug⟩-sub-filters" class="flex flex-wrap items-center gap-2"></div>
    </div>
</div>
```

**Cascata empilhada** (Checkpoint) — trocar o wrapper interno por
`space-y-3` no container e uma `<div>` por nível.

**Barra rolável** (Cronograma, quando há muitos controles):
`flex flex-nowrap items-center gap-3 overflow-x-auto` no wrapper interno.
Só é seguro porque o painel do dropdown é `position:fixed`.

---

## 4. Pills

**Helper compartilhado** (`renderPillFilters`, `05-gabinete-portfolio-reporte.js`) —
use este quando os itens vêm do banco:

```js
renderPillFilters({
    containerId: '⟨slug⟩-sub-filters',
    items: [{ id: null, label: 'Todas' }, ...db_subs.map(s => ({ id: s.id, label: s.nome }))],
    activeValue: ⟨estado⟩,
    onClickFn: 'set⟨Tela⟩Sub',   // o handler PRECISA fazer repactDec no argumento
    label: 'Subsecretaria'
});
```

```js
// handler correspondente — repactDec é obrigatório
function set⟨Tela⟩Sub(vEnc) {
    ⟨estado⟩ = repactDec(vEnc);
    render⟨Tela⟩View();
}
```

**Classe da pill** (para montar à mão) — `calPillCls`, `10-calendario.js`:

```js
const pillCls = (ativo) =>
    `px-4 py-2 rounded-full text-[11px] font-black uppercase tracking-wider transition-all border shadow-sm ${
        ativo ? 'bg-ses-green text-white border-ses-green shadow-md'
              : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'}`;
```

**Pills de módulo Projetos/Processos** — use `buildModoPills(modoAtual, 'set⟨Tela⟩Modo')`
de `03-componentes-compartilhados.js`, não reescreva.

---

## 5. Dropdown flutuante (muitas opções)

Gatilho **sempre branco**, mesmo com item selecionado — o rótulo já mostra a escolha.

```js
function ⟨slug⟩DropdownHTML() {
    const selecionado = ⟨lista⟩.find(x => String(x.id) === String(⟨estado⟩));
    const rotulo = selecionado ? selecionado.nome : 'Todos';
    const itemCls = (ativo) => `w-full text-left px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors ${ativo ? 'bg-ses-green/10 text-ses-green' : 'text-slate-600 hover:bg-slate-50'}`;
    const itens = `<button onclick="set⟨Slug⟩(null)" class="${itemCls(!⟨estado⟩)}">Todos</button>` +
        ⟨lista⟩.map(x => `<button onclick="set⟨Slug⟩('${x.id}')" class="${itemCls(String(⟨estado⟩) === String(x.id))}">${sanitize(x.nome)}</button>`).join('');
    return `
        <div class="inline-block shrink-0">
            <button onclick="toggle⟨Slug⟩Menu()" id="⟨slug⟩-btn"
                class="pl-3.5 pr-3 py-2 rounded-full border shadow-sm bg-white text-slate-600 border-slate-200 hover:border-slate-300 transition-all inline-flex items-center gap-2 text-xs font-bold">
                <i data-lucide="⟨icone⟩" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                <span class="max-w-[140px] truncate">${sanitize(rotulo)}</span>
                <i data-lucide="chevron-down" id="⟨slug⟩-chevron" class="w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform"></i>
            </button>
            <div id="⟨slug⟩-menu" class="hidden w-56 bg-white rounded-2xl shadow-2xl border border-slate-200 p-2 z-50 max-h-64 overflow-y-auto space-y-0.5" style="position:fixed">
                ${itens}
            </div>
        </div>`;
}

// fixed + left/top calculados do botão: escapa de qualquer overflow do pai
function toggle⟨Slug⟩Menu(forcarEstado) {
    const menu = document.getElementById('⟨slug⟩-menu');
    const btn  = document.getElementById('⟨slug⟩-btn');
    if (!menu || !btn) return;
    const mostrar = typeof forcarEstado === 'boolean' ? forcarEstado : menu.classList.contains('hidden');
    if (mostrar) {
        const r = btn.getBoundingClientRect();
        menu.style.left = r.left + 'px';
        menu.style.top  = (r.bottom + 8) + 'px';
    }
    menu.classList.toggle('hidden', !mostrar);
    document.getElementById('⟨slug⟩-chevron')?.classList.toggle('rotate-180', mostrar);
}
```

Fechar ao clicar fora e ao rolar qualquer container — copiar o listener de
`toggleAgendaSetorialistaMenu` (`10-calendario.js`):

```js
document.addEventListener('click', (e) => {
    const menu = document.getElementById('⟨slug⟩-menu');
    const btn  = document.getElementById('⟨slug⟩-btn');
    if (!menu || menu.classList.contains('hidden')) return;
    if (menu.contains(e.target) || (btn && btn.contains(e.target))) return;
    toggle⟨Slug⟩Menu(false);
});
// 'scroll' não borbulha, mas passa pela fase de captura em qualquer
// ancestral com listener nela — inclusive quando quem rolou é a PRÓPRIA
// lista do painel, se ela tiver overflow-y-auto (menu com muitos itens).
// SEM excluir esse caso, o gesto de rolar a lista fecha o painel antes de
// rolar qualquer coisa — a rolagem "não funciona". Já aconteceu em
// produção com o dropdown de setorialista.
window.addEventListener('scroll', (e) => {
    const menu = document.getElementById('⟨slug⟩-menu');
    if (menu && menu.contains(e.target)) return;
    toggle⟨Slug⟩Menu(false);
}, true);
```

---

## 6. Card de lista com identidade de eixo

Padrão do Cronograma: tile de ícone em gradiente do eixo (clicável, abre a
entidade), título, conteúdo, bloco de data à direita.

```js
function ⟨slug⟩CardHTML(item) {
    const isSes = eixoEhSes(item.eixo);
    const hex   = isSes ? '#f58220' : '#007fb6';
    const grad  = isSes ? 'from-ses-orange to-ses-darkorange' : 'from-ses-blue to-ses-darkblue';
    return `
        <div class="bg-white rounded-[28px] border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden">
            <div class="flex items-center gap-4 sm:gap-5 p-5">
                <button onclick="⟨abrirFn⟩('${item.id}')" title="Abrir"
                    class="w-14 h-14 rounded-2xl bg-gradient-to-br ${grad} flex items-center justify-center shadow-md hover:shadow-lg hover:scale-105 transition-all relative overflow-hidden shrink-0">
                    <div class="absolute -right-2 -top-3 w-9 h-9 bg-white/15 rounded-full pointer-events-none"></div>
                    <i data-lucide="${item.icone}" class="w-7 h-7 text-white relative z-10 pointer-events-none"></i>
                </button>
                <div class="flex-1 min-w-0">
                    <h3 class="text-lg font-black text-slate-800 tracking-tight leading-tight">${sanitize(item.nome)}</h3>
                    <!-- conteúdo -->
                </div>
                <div class="hidden md:block w-px h-10 bg-slate-100 shrink-0"></div>
                <div class="hidden md:flex flex-col items-end text-right gap-0.5 shrink-0 pl-2">
                    <p class="text-[9px] font-black text-slate-400 uppercase tracking-widest">⟨Rótulo⟩</p>
                    <p class="text-sm font-black text-slate-700 tnum">⟨valor⟩</p>
                </div>
            </div>
        </div>`;
}
```

**Card colapsável**: envolver o cabeçalho em
`<div onclick="toggle⟨X⟩('${key}')" class="cursor-pointer ...">` com o chevron
antes do tile, e usar `event.stopPropagation()` no botão interno:

```html
<div class="w-6 h-6 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 shrink-0 transition-transform ${aberto ? 'rotate-90' : ''}">
    <i data-lucide="chevron-right" class="w-4 h-4"></i>
</div>
```

Estado do que está aberto: um `Set` de chaves `` `${tipo}:${id}` `` no módulo.

---

## 7. Cabeçalho de subsecretaria

Já existe pronto: `buildSubHeaderHTML(subMeta, 'ses-green', 'ses-lightgreen')`
em `05-gabinete-portfolio-reporte.js`. Use-o em qualquer tela agrupada por sub —
**não reescreva**. Para uma view agrupada inteira, o caminho é
`renderGroupedView({...})`, não HTML novo.

---

## 8. Estado vazio

```html
<div class="bg-white rounded-[28px] border border-slate-100 shadow-sm py-20 flex flex-col items-center justify-center text-center">
    <div class="w-16 h-16 rounded-2xl bg-slate-50 text-slate-300 flex items-center justify-center mb-4">
        <i data-lucide="⟨icone-da-tela⟩" class="w-8 h-8"></i>
    </div>
    <p class="text-sm font-bold text-slate-400">⟨Frase específica do filtro ativo⟩</p>
</div>
```

A frase muda conforme o filtro ("Nenhum projeto para os filtros
selecionados." ≠ "Nenhum processo…"). Vazio genérico é preguiça.

---

## 9. Divisória de seção com contagem

```js
function ⟨slug⟩SecaoDividerHTML(label, icon, n) {
    return `
        <div class="flex items-center gap-3 pt-2">
            <div class="flex items-center gap-2 text-slate-400">
                <i data-lucide="${icon}" class="w-4 h-4"></i>
                <span class="text-[10px] font-black uppercase tracking-widest">${label}</span>
                <span class="text-[10px] font-black text-slate-300">(${n})</span>
            </div>
            <span class="flex-1 h-px bg-slate-200"></span>
        </div>`;
}
```

Só aparece quando há mais de um grupo com item — grupo único não precisa de rótulo.

---

## 10. Modal

```html
<div id="modal-⟨slug⟩" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div id="modal-⟨slug⟩-content" class="bg-white rounded-[32px] shadow-2xl w-full max-w-lg p-8 transform transition-all duration-200 scale-95 opacity-0">
        <h3 class="text-2xl font-black text-slate-800 mb-6 flex items-center gap-3">
            <div class="bg-ses-green/20 p-2 rounded-xl text-ses-green"><i data-lucide="⟨icone⟩" class="w-6 h-6"></i></div>
            ⟨Título⟩
        </h3>
        <!-- corpo -->
        <div class="flex justify-end gap-3">
            <button onclick="close⟨Slug⟩Modal()" class="px-6 py-3 rounded-2xl text-xs font-bold text-slate-500 hover:bg-slate-100 transition-colors uppercase tracking-widest">Cancelar</button>
            <button onclick="save⟨Slug⟩()" class="px-6 py-3 rounded-2xl text-xs font-bold text-white bg-ses-green hover:opacity-90 transition-colors flex items-center gap-2 uppercase tracking-widest shadow-md">
                <i data-lucide="save" class="w-4 h-4"></i> Salvar
            </button>
        </div>
    </div>
</div>
```

Abrir/fechar: remover `hidden` do overlay e, num `requestAnimationFrame` ou
`setTimeout(…, 10)`, trocar `scale-95 opacity-0` por `scale-100 opacity-100`.

**Variante destrutiva**: `max-w-md p-8 text-center`, círculo
`w-16 h-16 bg-red-50 text-red-500 rounded-full` com `alert-triangle`, título em
pergunta, botão `bg-red-500 hover:bg-red-600`.

---

## 11. Formulário

```html
<label class="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1 tracking-wider">⟨Rótulo⟩</label>
<input type="text" class="w-full border-2 border-slate-100 rounded-2xl p-4 text-xs font-bold outline-none bg-slate-50 focus:border-ses-green transition-all">
```

Textarea idem com `text-xs font-medium` e `rows`. Foco: `ses-green` em contexto
de sistema, `ses-blue` dentro de tela de projeto.

**Botão primário de formulário:**

```html
<button type="submit" class="w-full bg-ses-green hover:opacity-90 text-white py-4 rounded-2xl font-black tracking-widest shadow-md transition-all flex justify-center items-center gap-2">
    <i data-lucide="save" class="w-5 h-5"></i> SALVAR
</button>
```

---

## 12. Mouse-over — o `data-tip`

O mouse-over informativo é um dos padrões mais característicos do sistema: é
ele que permite a tela ficar limpa e mesmo assim carregar todo o detalhe. Não
é decoração — é **a metade escondida da divulgação progressiva**. Toda tela
nova com informação densa deve ter mouse-over; uma tela que precisa mostrar
tudo na superfície está mal desenhada.

### Como funciona

Um único `#global-tip` `position:fixed` anexado ao `<body>`
(`03-componentes-compartilhados.js`), disparado pelo atributo `data-tip` em
qualquer elemento, via listener delegado no `document`. Por ser `fixed` e filho
direto do `body`, **escapa de qualquer `overflow:hidden/auto`** — células do
calendário, trilhas do cronograma, barras com rolagem horizontal. Era
exatamente isso que recortava a dica quando o tooltip era `absolute`.

Comportamento pronto, sem configuração: aparece **acima** do elemento; vira
para baixo quando não cabe (`.tip-below`); fica preso à viewport com margem de
8px; a seta acompanha o centro do gatilho (`--tip-arrow`); e some no clique e
em qualquer rolagem (listeners em fase de captura).

### `data-tip` ou `title`?

A divisão é real no código e deve ser respeitada:

| | Use | Exemplos no sistema |
|---|---|---|
| **`title="…"`** | Rótulo curto que **nomeia um controle** — a afordância do botão | `title="Recolher menu"`, `title="Linha do tempo"`, `title="Abrir projeto"`, `title="Editar informações do processo"` |
| **`data-tip="…"`** | **Informação derivada dos dados**: longa, de várias linhas, ou que não caberia na tela | Desvio em dias no Cronograma, última atualização do marco, meta completo (sub, gerente, setorialista), valor anterior de um marco editado, e-mail do setorialista, "Pactuado em … (fim de semana)" |

Regra prática: se o texto **descreve o botão**, é `title`. Se **é conteúdo**,
é `data-tip`.

### Uso — linha única

```js
`<div data-tip="${sanitize(email)}" class="…">${sanitize(nome)}</div>`
```

**Condicional** — quando não há o que dizer, o atributo não é emitido (um
`data-tip=""` mostraria um balão vazio):

```js
`<span ${subMeta?.nome ? `data-tip="${sanitize(subMeta.nome)}"` : ''} class="…">${sanitize(sigla)}</span>`
```

### Uso — várias linhas (o padrão preferido)

Monte um array de linhas, descarte as vazias, junte com `'\n'` **literal** e
sanitize o conjunto. A quebra funciona porque o balão tem
`white-space: pre-line`.

```js
const tip = [
    it.titulo,
    `Pactuado: ${calFmtBr(pact)}`,
    `${concluido ? 'Concluído' : 'Previsto'}: ${calFmtBr(real)}`,
    (desvio !== null && desvio !== 0)
        ? `${atrasou ? 'Atraso' : 'Adiantamento'} de ${Math.abs(desvio)} dia${Math.abs(desvio) === 1 ? '' : 's'}`
        : null,
    CAL_STATUS_LABEL[se]
].filter(Boolean).join('\n');

return `<div class="…" data-tip="${sanitize(tip)}">${sanitize(it.titulo)}</div>`;
```

Ordem das linhas: **identidade primeiro** (o quê), depois os números, depois a
situação. Mesma ordem em todos os tooltips do sistema.

### Gatilho em ícone — sempre num wrapper

`lucide.createIcons()` substitui o `<i data-lucide>` por um `<svg>`. **Nunca
ponha `data-tip` no `<i>`** — ponha num `<span class="inline-flex">` em volta.
O `inline-flex` é o que dá ao wrapper uma caixa colada ao ícone, que é o
retângulo medido para posicionar o balão.

```js
`<span class="inline-flex" data-tip="${miConcluidos}/${miTotal} ${plural}">
    <button onclick="…" class="…"><i data-lucide="list-checks" class="w-3.5 h-3.5"></i></button>
</span>`
```

### Gatilho que só aparece no hover do card

Para ações discretas (o "+" de marco intermediário, a prancheta do critério de
aceitação): `group` no card, e no wrapper —

```js
`<span class="inline-flex opacity-0 group-hover:opacity-100 transition-opacity" data-tip="Adicionar marco intermediário">
    <button …><i data-lucide="plus" class="w-3.5 h-3.5"></i></button>
</span>`
```

### Regras que não podem ser quebradas

- **`sanitize()` sempre.** O valor entra num atributo HTML; uma aspa dupla no
  dado fecha o atributo e quebra a marcação.
- **Só texto puro.** O balão é preenchido com `textContent`, nunca
  `innerHTML` — o atributo HTML já decodifica um nível, então `textContent` é
  o único caminho seguro. Não adianta mandar `<b>` ou `<br>`: use `'\n'`.
- **Nada de `data-tip` no `<i data-lucide>`** (ver acima).
- **Nada essencial só no mouse-over.** Toque e teclado não têm hover: o
  mouse-over aprofunda, nunca é o único caminho para uma informação necessária.
- **Um tooltip por gatilho.** Aninhar elementos com `data-tip` faz o
  `closest()` pegar o mais interno — raramente é o que se quer.

---

## 13. Chips

**Chip de status:**

```html
<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 text-[10px] font-black uppercase tracking-wider text-slate-500">
    <span class="w-2 h-2 rounded-full ${CAL_STATUS_DOT[status]}"></span>${CAL_STATUS_LABEL[status]}
</span>
```

---

## 14. Esqueleto da função de render

```js
function render⟨Tela⟩View() {
    const container = document.getElementById('⟨slug⟩-container');
    if (!container) return;

    const header  = `⟨hero⟩`;
    const filtros = `⟨barra de filtros⟩`;
    const corpo   = itens.length
        ? `<div class="flex flex-col gap-8">${itens.map(⟨slug⟩CardHTML).join('')}</div>`
        : `⟨estado vazio⟩`;

    container.innerHTML = `
        <div class="fade-in space-y-6">
            ${header}
            ${filtros}
            ${corpo}
        </div>`;

    lucide.createIcons();   // obrigatório após todo innerHTML
}
```

---

## 15. Interação local não re-renderiza a view

Expandir um card, girar um chevron, marcar um item — **nada disso pode passar
pela função de render da tela inteira.** Trocar o `innerHTML` do container
descarta e remonta a lista toda: as animações de entrada e de progresso
recomeçam do zero e a tela **pisca** para atender a um clique num único card.
(No Cronograma isso era feito assim e teve de ser corrigido.)

Padrão: marque os pontos de ancoragem na marcação e altere só eles.

```js
function toggle⟨X⟩(key) {
    const abrindo = !⟨estadoSet⟩.has(key);
    if (abrindo) ⟨estadoSet⟩.add(key); else ⟨estadoSet⟩.delete(key);

    // getAttribute em vez de seletor de atributo: não depende de escapar a
    // chave dentro do seletor CSS.
    const card = [...document.querySelectorAll('[data-⟨x⟩-card]')]
        .find(el => el.getAttribute('data-⟨x⟩-card') === key);
    const painel = card && card.querySelector('[data-⟨x⟩-painel]');
    if (!card || !painel) { render⟨Tela⟩View(); return; }   // fallback: saiu do DOM

    painel.innerHTML = abrindo ? `<div class="fade-in">${⟨painelHTML⟩(key)}</div>` : '';
    if (abrindo) lucide.createIcons({ nodes: [painel] });
    card.classList.toggle('ring-1', abrindo);
    card.querySelector('[data-⟨x⟩-chevron]')?.classList.toggle('rotate-90', abrindo);
}
```

Re-render completo continua certo quando o **conteúdo da lista muda de fato**:
troca de filtro, de ordenação, ou item que muda de grupo. Aí a entrada
escalonada é desejável — ela comunica que a lista é outra.

---

## 16. Escrita otimista

```js
async function salvar⟨X⟩(id, valores) {
    if (!roleCanWrite()) return;
    const { error } = await _supabase.from('⟨tabela⟩').update(valores).eq('id', id);
    if (error) { showErrorToast('Erro ao salvar: ' + error.message); return; }
    const local = db_⟨tabela⟩.find(x => String(x.id) === String(id));
    if (local) Object.assign(local, valores);   // reflete no global — sem invalidar cache
    render⟨Tela⟩View();
    showToast('⟨Confirmação em uma frase⟩');
}
```
