---
name: "paper-dados-saude-ses"
description: "Cria \"papers\" objetivos em HTML — relatórios de dados e resultados de saúde (SAMU, UBS, Opera Mais, Valora Minas, hospitais regionais, PPPs como o HoPE, entregas e investimentos em geral) da SES-MG/AEST, destinados a autoridades como o governador ou secretários, na identidade visual do sistema de governança da AEST/SES-MG (verde institucional, cards de números grandes, tabelas, gráficos de barra, timelines, chips de status). Use sempre que Paulo pedir um \"paper\", um \"relatório em HTML\" ou \"bonito\", ou pedir para transformar dados de saúde (Word, planilhas, PDFs, números soltos, imagens de tabela) num documento visual para uma autoridade — mesmo que ele não diga \"HTML\" ou \"paper\" explicitamente, por exemplo \"monta um resumo bonito desses números pro governador\" ou \"transforma isso num relatório visual\". Esta skill SEMPRE pergunta sobre lacunas, divergências entre fontes e pontos de decisão nos dados antes de produzir o HTML, e a cada rodada de dados novos — não só na primeira vez."
---

# Paper de dados de saúde (SES-MG/AEST) — HTML

## O que é este entregável

Um "paper" é um único arquivo HTML autocontido — sem build, sem
dependência de arquivo externo além de CDNs (Tailwind, Google Fonts,
Lucide) — que apresenta **dados e resultados objetivos** de um ou mais
programas de saúde de Minas Gerais (SAMU, UBS, Opera Mais, Valora Minas,
hospitais regionais, PPPs de saúde etc.) para uma autoridade (governador,
secretário). Não é um relatório institucional cheio de texto: é
essencialmente números grandes, tabelas e gráficos, na identidade visual
do sistema de governança interno da AEST/SES-MG.

Isto é diferente da skill `auditoria-governanca-ses`: aquela mexe no
código-fonte do sistema de governança de verdade (o repositório). Esta
skill nunca toca o repositório — só produz um HTML solto para entregar
como arquivo.

## Passo 0 — leia os documentos de referência

Antes de escrever qualquer HTML nesta sessão, se ainda não leu:

1. `references/identidade-visual.md` — paleta, tipografia, geometria de
   raios, texturas (onda, orbes, glass), regras de UI/UX do sistema
   inteiro. É a fonte da verdade de estilo.
2. `references/padroes-html.md` — o mesmo traduzido em componentes
   prontos para copiar (hero, pills, cards, tabelas, gráfico de barras,
   círculo dividido em N, timeline, chip de status, callout). Comece
   copiando daqui em vez de reinventar cada peça.
3. `assets/exemplo-paper-saude-mg.html` — um paper inteiro, real, já
   revisado por várias rodadas com o Paulo. Serve de referência de
   estrutura completa e de "como ficou bom da última vez".

`references/componentes.md` também está disponível (é o inventário
completo de componentes do sistema de governança) — mais detalhado do
que esta skill normalmente precisa, mas consulte se `padroes-html.md`
não cobrir alguma dúvida específica de padrão visual.

## Passo 1 — leia os dados inteiros antes de decidir qualquer coisa

Receba os arquivos que o Paulo mandar (docx, xlsx, csv, imagens, texto
colado) e leia **tudo**, não só o que parece relevante à primeira vista:

- **.docx**: converta com `pandoc -t markdown arquivo.docx -o saida.md`
  para pegar o texto corrido. Se houver tabelas como imagem embutida
  (comum em documentos exportados de outro sistema), extraia com
  `unzip -o arquivo.docx -d pasta/` e abra `pasta/word/media/*.png`
  com `view` — o pandoc não lê texto dentro de imagem.
- **.xlsx**: abra com `openpyxl` (`read_only=True, data_only=True`),
  liste as abas primeiro (`wb.sheetnames`) e os cabeçalhos de cada uma
  antes de agregar. Agregue por ano/categoria com um dicionário, nunca
  assumindo a ordem das linhas.
- **.csv**: teste o encoding (`latin-1` é comum em exportações de
  sistemas de governo brasileiros; `utf-8` falha nesses casos com erro
  de decode). Use `;` como delimitador se `,` não separar nada.
- **Dados colados no chat** (tabelas em texto, como as que o Paulo já
  mandou direto na mensagem): trate como fonte primária igual a um
  arquivo — não são menos confiáveis só por não serem um upload.

## Passo 2 — SEMPRE pergunte antes de produzir

Este é o requisito mais importante da skill: **nunca gere o HTML na
primeira resposta depois de receber dados novos**, mesmo que pareçam
completos. Revise o que foi lido e procure por:

- **Números que não batem entre fontes diferentes** para o mesmo dado
  (duas planilhas com totais diferentes, um Word com um número que a
  apuração física não confirma). Não escolha uma por conta própria —
  pergunte qual usar.
- **Períodos ambíguos** — ano parcial, corte de data, um "até junho"
  escondido em nota de rodapé do documento fonte.
- **Somas ou totais que você teria que calcular** e que não estavam
  explícitos na fonte (ex.: somar duas linhas da planilha que parecem
  ser o mesmo item). Confirme a conta antes de publicar.
- **Métricas que se sobrepõem** — um total que já contém outro (ex.:
  programa B financia parte do programa A) e por isso não pode ser
  somado ao lado dele sem nota.
- **Categorias/linhas que faltam** para completar um tópico pedido
  (ex.: pediram 5 itens, a fonte só trouxe 4).
- **Nomenclatura/rótulo ambíguo** — mais de uma forma razoável de
  nomear ou agrupar a mesma coisa.

Apresente os pontos como **lista numerada, cada um com sua sugestão de
default**, para o Paulo poder responder rápido ("tudo ok" ou só os
números que quer mudar) — é exatamente o formato que funcionou nas
primeiras rodadas desta skill. Não pergunte por perguntar: se os dados
vieram limpos e você não achou nenhum ponto real de dúvida, diga isso em
uma frase e siga direto para o HTML.

**Isto vale de novo a cada nova entrega de dados**, não só na primeira
versão do paper — quando o Paulo manda uma correção ou um tópico novo
com números, faça a mesma varredura antes de editar. (Não é necessário
para pedidos puramente de estilo/layout que não tocam em dado nenhum —
"centraliza essa barra" não precisa de rodada de perguntas.)

Depois de publicar, se você mesmo precisou presumir, arredondar ou somar
algo para fechar uma lacuna, **diga isso explicitamente na resposta**
(o que foi assumido e por quê) mesmo que o Paulo tenha dito para seguir
sem perguntar antes — transparência depois de produzir não substitui a
pergunta antes, mas é sempre devida.

## Passo 3 — monte o HTML

Estrutura padrão (ver `references/padroes-html.md` para o código de
cada peça):

1. Hero verde (ícone + eyebrow "Secretaria de Estado de Saúde de Minas
   Gerais · SES-MG" + título do paper). Nada à direita do hero por
   padrão.
2. Barra de navegação com uma pill centralizada por tema, rolando até a
   seção via scroll-spy.
3. Uma `<section>` por tema, cada uma com: tile de ícone + "Tema 0N" +
   título; parágrafo de contexto **só se agregar informação real**;
   números grandes em destaque; tabelas e/ou gráficos de barra;
   callout quando houver algo que não pode ser somado ou que precisa de
   nota.
4. Rodapé verde repetindo o motivo do hero, com botão de imprimir.

Regras de tom, já validadas com o Paulo em várias rodadas:

- **Objetivo e sucinto.** Números primeiro, texto só quando o número
  sozinho não basta. Nada de frase de efeito nem preâmbulo.
- **Sinalize parcial.** Ano corrente incompleto = "(parcial)" visível,
  não escondido em nota de rodapé.
- **Não invente precisão desnecessária.** Se um valor for claramente
  uma estimativa arredondada, marque com `≈` em vez de escrever como se
  fosse exato. Também pode arredondar um valor oficial preciso quando
  achar que fica mais legível (ex.: `R$ 677,9 mi` em vez de
  `R$ 677.880.502,06`) — use o bom senso do contexto: cabeçalho e cards
  de destaque toleram arredondar, tabela de execução financeira linha a
  linha normalmente não.
- **Avisos de "não somar"** (quando duas métricas se sobrepõem) em
  card sólido/gradiente chamativo — não em amarelo/âmbar, que lê como
  alerta de erro.
- **Dado ausente nunca vira `—` por conta própria.** Ausência de dado é
  sempre um ponto do Passo 2 — pergunte ao Paulo antes de decidir como
  representar (deixar de fora do tópico, usar `—`, buscar em outra
  fonte). Só use `—` na tabela depois que ele confirmar que é isso
  mesmo que ele quer.
- **Chip de status curto + detalhe no tooltip (`data-tip`)** quando o
  status tiver uma frase inteira de nuance atrás (ver seção 12 do
  cookbook) — não esprema o parágrafo inteiro dentro do chip nem jogue
  a nuance fora.

## Passo 4 — entregue

- Salve com `create_file` em `/mnt/user-data/outputs/`, nome de arquivo
  descritivo (`paper-<tema>.html`).
- Rode o checklist de tags balanceadas (seção 15 do cookbook) antes de
  considerar pronto — depois de escrever pela primeira vez e depois de
  **cada** edição subsequente.
- Chame `present_files` com o caminho do HTML.
- Não gere PDF nem screenshot para conferência: os ambientes de execução
  costumam não ter acesso aos CDNs (Tailwind/Fonts/Lucide) que o arquivo
  usa, então o print sairia sem estilo mesmo com o HTML correto — a
  checagem de tags balanceadas é o que garante a estrutura.

## Editando um paper já entregue

Pedidos de ajuste (trocar um número, adicionar um tópico, mudar uma cor)
são o modo normal de uso depois da primeira entrega — não recrie o
arquivo do zero. Use `str_replace` em cima do arquivo em
`/mnt/user-data/outputs/`, rode o checklist de balanceamento depois, e
já reapresente com `present_files`. Se o pedido trouxer **dados novos**
(não só estilo), volta o Passo 2 — pergunte antes de aplicar.
